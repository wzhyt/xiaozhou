<?php
header("Content-Type: text/html;charset=utf-8");
    //获取配置文件
    $json = file_get_contents('Config.json'); 
    //强制转换为数组
    $data = json_decode($json, true); 
    //获取数据库结构文件
    $sql = file_get_contents('config.sql');
    
    $sql = str_replace("tk_",$data["prefix"],$sql);
    
    $arr = explode(';', $sql);
    
    $_mysqli = new mysqli($data['hostname'],$data['username'],$data['password'],$data['database']);
     mysqli_set_charset($_mysqli,'utf8');
    if (mysqli_connect_errno()) {
        return json_encode([
               "statu" => "0",
               "data" => "数据库连接失败"
               ]);
               die;
    }
    //执行sql语句
    foreach ($arr as $_value) {
        $_mysqli->query($_value.';');
    }
    $_mysqli->close();
    return true;
?>