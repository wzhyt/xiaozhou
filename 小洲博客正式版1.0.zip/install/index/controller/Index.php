<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Cookie;
use think\Session;
use think\Config;
use think\Query;
use app\index\validate\Data as Data;
//最低支持版本
const V = 5.5;
//生成的数据表数量
const Length = 9;
class Index extends Controller
{
    public function data(){
        $path = "../";
        $put = (is_dir($path)||mkdir($path,0755,true))?true:false;
        $vf = (PHP_VERSION>=V)?true:false;
        $file_get = (function_exists("file_get_contents"))?true:false;
        $file_put = (function_exists("file_put_contents"))?true:false;
        $mail = (function_exists("fsockopen"))?true:false;
        //数据库安装了多少张表
        $source = APP_PAHH ."database.php";
        $dest = APP_PATH ."database.php";
        if(file_exists("Config.json")&&file_exists($source)&&file_exists($dest)){
            $length = count(Db::query("show tables"));
            $lenf = $length>=Length?true:false;
        }else{
            $length = 0;
            $lenf = false;
        }
        
        $data = [
            "v" => PHP_VERSION,
            "vf" => $vf,
            "put" => $put,
            "file_get" => $file_get,
            "file_put" => $file_put,
            "mail" => $mail,
            "demand" => V,
            "Length" => Length,
            "length" => $length,
            "lenf" => $lenf
                ];
           return $data;
    }
    public function Index(){
        $data = $this->data();
        $this->assign('data',$data);
        return $this->fetch();
    }
   public function box1(){
        return $this->fetch();
   }
   public function box2(){
        $data = $this->data();
        $this->assign('data',$data);
        return $this->fetch();
   }
   public function box3(){
        return $this->fetch();
   }
   public function box4(){
        return $this->fetch();
   }
   public function box5(){
        //数据库安装了多少张表
        $length = count(Db::query("show tables"));
        $lenf = $length>=Length?true:false;
        $data  = [
            "Length" => Length,
            "length" => $length,
            "lenf" => $lenf
            ];
        $this->assign('data',$data);
        return $this->fetch();
   }
   public function box6(){
        return $this->fetch();
   }
   public function aaa(){
       $data = $_SERVER['HTTP_HOST'];
       $this->assign("data",$data);
        return $this->fetch();
   }
   public function put(){
       if(PHP_VERSION<V){
           return $this->Wrong("PHP版本不支持");
       }
        $data = input("post.");
        $val = new Data();
        //验证数据
		if(!$val->check($data)){
    		$outstr = iconv('GBK','UTF-8',$val->getWrong());
    		echo json_encode([
    		    "statu" => "-1",
    		    "toas" => $outstr
    		    ]);
    		    return;
		}
        $let = $this->setconfig("database",$data);
        if(!$let){
            echo $this->Wrong("数据库配置失败");
            return;
        }
        
        //生成配置文件
        $file = fopen("Config.json", "w") or die("Failed to generate folder!");
        $txt = '{"hostname":"'.$data['hostname'].'",';
        $txt .= '"hostport":"'.$data['hostport'].'",';
        $txt .= '"username":"'.$data['username'].'",';
        $txt .= '"password":"'.$data['password'].'",';
        $txt .= '"database":"'.$data['database'].'",';
        $txt .= '"prefix":"'.$data['prefix'].'"}';
        fwrite($file, $txt);
        fclose($file);
        $source = APP_PAHH ."database.php";

        $dest = APP_PATH ."database.php";

        if(copy($source,$dest)){
            echo $this->Correct("数据库配置成功");
        }else{
            echo $this->Wrong("数据库配置失败");
            unlink("Config.json");
        }
        
   }
    public function base(){
        $source = APP_PAHH ."database.php";

        $dest = APP_PATH ."database.php";
        
        if(!(file_exists("Config.json")&&file_exists($source)&&file_exists($dest))){
            echo $this->Wrong("核心文件丢失");
            die;
        }
        include(APP_PATH.'yun.php');
        if($this->fofo()){
            echo $this->Wrong("数据表丢失");
            die;
        }
            echo $this->Correct("数据表创建成功");
    }
    public function con(){
       if($this->fofo()){
            echo $this->Wrong("数据表丢失");
            die;
        }
        $source = "database.php";

        $dest = "database.php";

        if(!copy("Config.json","config.json")){
            echo $this->Wrong("数据库配置失败");
            unlink("config.json");
            die;
        }
        $data = input("post.");
        $time = date("Y-m-d H:i:s",time());
        $req = Request::instance();
		$ip = $req->ip();
        $user = [
            "create_time" => $time,
            "update_time" => $time,
            "ip" => $ip,
            "yh" => "站长",
            "qq" => $data["qq"],
            "name" => $data["name"],
            "password" => $data["password"],
            "repassword" => $data["password"]
            ];
        $tab = Db::name("user")->insert($user);
        $allsz = [
            "opentime" => time(),
            "title" => $data["title"],
            "QQ" => $data["qq"],
            ];
        $tba = Db::name("allsz")->insert($allsz);
        if(!($tab&&$tba)){
            unlink("config.json");
            echo $this->Wrong("创建失败");
            die;
        }
        
        $rut = "<div class='form'>
                    <div class='card bg-success text-white'>
                    <div class='card-body'>
                        <font size='4' color='#ff3f34'>博客安装成功，请记住后台地址，本页面刷新将不存在</font><br />
                        首页：<a href='/'>".$_SERVER['HTTP_HOST']."</a><br />
                        后台：<a href='/admin'>".$_SERVER['HTTP_HOST']."/admin</a><br />
                        <small>如何需要重装请删除public目录下的config.json文件即可（public目录下有安装说明文件）</small>
                    </div>
                    </div>
                </div>";
        echo json_encode([
               "statu" => "1",
               "data" => "博客程序安装成功",
               "hint" => $rut
               ]);
       
        //删除数据库临时配置文件
        unlink("Config.json");
    }
    public function setconfig($file,$data){
        if (is_array($data)){
        	$fileurl = APP_PAHH .$file.".php";
            $string = file_get_contents($fileurl); //加载配置文件
        	foreach ($data as $key => $value) {
        		$pats = '/\'' . $key . '\'(.*?)\',/';
        		$reps = "'". $key. "'". "			=> " . "'".$value ."',";
        		$string = preg_replace($pats, $reps, $string); // 正则查找然后替换
        	}
        	file_put_contents($fileurl, $string); // 写入配置文件
            return true;
        }else{
            return false;
        }
    }
    public function Wrong($data){
        return json_encode([
               "statu" => "0",
               "data" => $data
               ]);
    }
    public function Correct($data){
        return json_encode([
               "statu" => "1",
               "data" => $data
               ]);
    }
    public function fofo(){
        $json = file_get_contents('Config.json'); 
        //强制转换为数组
        $data = json_decode($json, true); 
        $length = count(Db::query("show tables"));
        if($length<Length){
            $del = "DROP TABLE tk_allsz, tk_column, tk_feedback, tk_hd, tk_link, tk_rz, tk_seeding, tk_win, tk_user";
            $del = str_replace("tk_",$data["prefix"],$del);
            $dl = Db::query($del);
            return true;
        }
    }
}