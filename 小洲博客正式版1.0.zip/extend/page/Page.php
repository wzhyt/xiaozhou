<?php

namespace page;

// +----------------------------------------------------------------------

// | ThinkPHP [ WE CAN DO IT JUST THINK ]

// +----------------------------------------------------------------------

// | Copyright (c) 2006~2017 http://thinkphp.cn All rights reserved.

// +----------------------------------------------------------------------

// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )

// +----------------------------------------------------------------------

// | Author: zhangyajun <448901948@qq.com>

// +----------------------------------------------------------------------

  

use think\Paginator;

  

class Page extends Paginator

{

  

    //首页

    protected function home() {

        if ($this->currentPage() > 1) {

            return "<a href='" . $this->url(1) . "' title='首页'>首页</a>";

        } else {

            return "";

        }

    }

  

    //上一页

    protected function prev() {

        if ($this->currentPage() > 1) {

            return "<a href='" . $this->url($this->currentPage - 1) . "' title='上一页'><</a>";

        } else {

            return "<p>《</p>";
            
        }

    }

  

    //下一页

    protected function next() {

        if ($this->hasMore) {

            return "<a href='" . $this->url($this->currentPage + 1) . "' title='下一页'>></a>";

        } else {

            return"<p>》</p>";

        }

    }

  

    //尾页

    protected function last() {

        if ($this->hasMore) {

            return "<a href='" . $this->url($this->lastPage) . "' title='尾页'>尾页</a>";

        } else {

            return "";

        }

    }

  

    //统计信息

    protected function info(){

        return "<span data-container='body' data-toggle='popover' data-trigger='hover' data-placement='bottom' 
			data-content='第 ".$this->currentPage." 页,共 ".$this->lastPage." 页' class='pageRemark'><b>" . $this->total . "</b>条文章</span>";

    }

  

    /**

     * 页码按钮

     * @return string

     */

    protected function getLinks()

    {

  

        $block = [

            'first'  => null,

            'slider' => null,

            'last'   => null

        ];

  

        $side   = 3;

        $window = $side * 2;

  

        if ($this->lastPage < $window + 6) {

            $block['first'] = $this->getUrlRange(1, $this->lastPage);

        } elseif ($this->currentPage <= $window) {

            $block['first'] = $this->getUrlRange(1, $window + 2);

            $block['last']  = $this->getUrlRange($this->lastPage - 1, $this->lastPage);

        } elseif ($this->currentPage > ($this->lastPage - $window)) {

            $block['first'] = $this->getUrlRange(1, 2);

            $block['last']  = $this->getUrlRange($this->lastPage - ($window + 2), $this->lastPage);

        } else {

            $block['first']  = $this->getUrlRange(1, 2);

            $block['slider'] = $this->getUrlRange($this->currentPage - $side, $this->currentPage + $side);

            $block['last']   = $this->getUrlRange($this->lastPage - 1, $this->lastPage);

        }

  

        $html = '';

  

        if (is_array($block['first'])) {

            $html .= $this->getUrlLinks($block['first']);

        }

  

        if (is_array($block['slider'])) {

            $html .= $this->getDots();

            $html .= $this->getUrlLinks($block['slider']);

        }

  

        if (is_array($block['last'])) {

            $html .= $this->getDots();

            $html .= $this->getUrlLinks($block['last']);

        }

  

        return $html;

    }

  

    /**

     * 渲染分页html

     * @return mixed

     */

    public function render()

    {

        if ($this->hasPages()) {

            if ($this->simple) {

                return sprintf(

                    '%s<div class="pagination">%s %s %s</div>',

                    $this->css(),

                    $this->prev(),

                    $this->getLinks(),

                    $this->next()

                );

            } else {

                return sprintf(

                    '%s<div class="pagination">%s %s %s %s %s %s</div>',

                    $this->css(),

                    $this->home(),

                    $this->prev(),

                    $this->getLinks(),

                    $this->next(),

                    $this->last(),

                    $this->info()

                );

            }

        }

    }

  

    /**

     * 生成一个可点击的按钮

     *

     * @param  string $url

     * @param  int    $page

     * @return string

     */

    protected function getAvailablePageWrapper($url, $page)

    {

        return '<a href="' . htmlentities($url) . '" title="第'. $page .'页" >' . $page . '</a>';

    }

  

    /**

     * 生成一个禁用的按钮

     *

     * @param  string $text

     * @return string

     */

    protected function getDisabledTextWrapper($text)

    {

        return '<p class="pageEllipsis">' . $text . '</p>';

    }

  

    /**

     * 生成一个激活的按钮

     *

     * @param  string $text

     * @return string

     */

    protected function getActivePageWrapper($text)

    {

        return '<a href="javascript:;" class="cur">' . $text . '</a>';

    }

  

    /**

     * 生成省略号按钮

     *

     * @return string

     */

    protected function getDots()

    {

        return $this->getDisabledTextWrapper('...');

    }

  

    /**

     * 批量生成页码按钮.

     *

     * @param  array $urls

     * @return string

     */

    protected function getUrlLinks(array $urls)

    {

        $html = '';

  

        foreach ($urls as $page => $url) {

            $html .= $this->getPageLinkWrapper($url, $page);

        }

  

        return $html;

    }

  

    /**

     * 生成普通页码按钮

     *

     * @param  string $url

     * @param  int    $page

     * @return string

     */

    protected function getPageLinkWrapper($url, $page)

    {

        if ($page == $this->currentPage()) {

            return $this->getActivePageWrapper($page);

        }

  

        return $this->getAvailablePageWrapper($url, $page);

    }

  

    /**

     * 分页样式

     */

    protected function css(){

        return '  <style type="text/css">

            .pagination p{

                margin:0;

                display:none;

            }

            .pagination{
            
            	margin: 15px 0 0 0;
            	
        		display:flex;
        		
        		justify-content: center;
        		
                flex-wrap: wrap;
                
                font-size:1.2em;
            }
            .pagination span{
                padding: 2.5px 10px 2.5px 10px;
            }
            .pagination a{

                display:block;

                float:left;

                margin-right:10px;

                padding:2.5px 10px 2.5px 10px;

                background:#fff;

                text-decoration:none;

                color:#808080;
                
                border-radius: 5px;

            }

            .pagination .cur,.pagination a:hover{

                background:#25b6ed;

                color:white;

            }

            .pagination a.cur{

                border:none;
                
                cursor:default;
                
                user-select:none;

                background:#25b6ed;

                color:white;

            }

            .pagination p{

                float:left;

               padding:2.5px 10px 2.5px 10px;

                font-size:12px;

                color:#bbb;

                background:#25b6ed;

                margin-right:8px;

  

            }

            .pagination p.pageRemark{

                border-style:none;

                background:none;

                margin-right:0px;

                padding:2.5px 10px 2.5px 10px;

                color:#666;

            }

            .pagination b{

                color:red;

            }

            .pagination p.pageEllipsis{

                border-style:none;

                background:none;

                padding:4px 0px;

                color:#808080;

            }

            .dates li {font-size: 14px;margin:20px 0}

            .dates li span{float:right}

        </style>';

    }

}