<?php
use think\Route;
Route::rule('/','index/Index/index');
Route::rule('login','index/Index/login');
Route::rule('time','index/Index/time');
Route::rule('tags','index/Index/tags');
Route::rule('web/[:id]','index/Index/web');
// Route::rule('web/:bk/[:id]','index/Index/web','GET',['ext'=>'htmL']);
Route::rule('stas','index/Index/stas');
Route::rule('cs','index/Index/cs');
Route::rule('pro','index/User/pro');
Route::rule('post','index/User/post');
Route::rule('search','index/Index/search');
Route::rule('email','index/Index/email');
Route::rule('ned','index/Index/ned');
Route::rule('ned1','index/Index/ned1');
Route::rule('check','index/Index/check');
Route::rule('admin/[:name]','index/User/admin');
Route::rule('foot','index/Index/foot');
Route::rule('box1','index/Index/box1');
Route::rule('box2','index/Index/box2');
//QQ登陆回调
Route::rule('tencent','index/Index/tencent');
//导航路由
Route::rule('menu/[:name]','index/Index/menu');
return [
    '__pattern__' => [
        'name' => '\w+',
    ],
    '[hello]'     => [
        ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
        ':name' => ['index/hello', ['method' => 'post']],
    ],

];
