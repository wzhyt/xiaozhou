<?php
namespace app\index\validate;
use think\Validate;
class User extends Validate
{
	protected $rule = [
		'name|用户名'=>'require|min:3',
		'password|密码'=>'require|min:2',
	];
	protected $message = [
		'name.require'=>'用户名不能为空',
		'name.min'=>'用户名长度不够',
		'password.require'=>'密码不能为空',
		'password.min'=>'密码长度不够',
	];
}