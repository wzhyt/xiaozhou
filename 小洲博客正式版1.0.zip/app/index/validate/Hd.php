<?php
namespace app\index\validate;
use think\Validate;
class Hd extends Validate
{
	protected $rule = [
		'title|标题'=>'require|min:2',
		'js|简述'=>'require|min:8',
		'bq|标签'=>'require|min:2',
		'content|内容'=>'require|min:10',
	];
	protected $message = [
		'title.require'=>'标题不能为空',
		'title.min'=>'标题长度最少2位',
		'js.require'=>'简述不能为空',
		'js.min'=>'简述长度最少8位',
		'bq.require'=>'标签不能为空',
		'bq.min'=>'标签长度最少2位',
		'content.require'=>'内容不能为空',
		'content.min'=>'内容长度最少10位',
	];
}