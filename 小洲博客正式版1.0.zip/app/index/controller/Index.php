<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Cookie;
use think\Session;
use think\Config;
use app\index\model\Udata as Udata;
use app\index\model\Feedback as Feed;
use app\index\model\Hd as Hd;
class Index extends Cook
{
	public function index()
	{
		$user = new Hd();
		$call = $user->IndexData();
		$this->assign('call',$call);
		return $this->fetch();
	}
		//集体数据函数
	public function data(){
		//文章
		$user = db('hd');
		//获取所有文章并按最新时间排序
		$data = $user->order(['update_time' => 'desc'])->select();
		//只获取十条文章进行分页
		$idata = $user->order(['update_time' => 'desc'])->paginate(10);
		//首页分页
		$ipage = $idata->render();
		//获取网站基本信息
		$all = Db::name('allsz')->find();
		//获取导航栏信息
		$column = Db::name('column')->select();
		//统计帖子数
		$sum = $user->count();
		//博客日记
		$diary = $user->limit(3)->where("statu",0)->order(['update_time' => 'desc'])->select();
		//个人博客搭建
		$blog = $user->limit(3)->where("statu",1)->order(['update_time' => 'desc'])->select();
		//最新资讯
		$cment = $user->limit(4)->order(['update_time' => 'desc'])->select();
		//站长推荐
		$mend = $user->limit(6)->where("mend",1)->order(['update_time' => 'desc'])->select();
		//友情链接
		$link = Db::name('link')->limit(3)->select();
		//选项卡1·博客日记
		$tabs1 = $user->where("statu",1)->limit(4)->order(['update_time' => 'desc'])->select();
		//选项卡2·友情链接
		$tabs2 = Db::name('link')->limit(4)->select();
		//选项卡3·个人博客搭建
		$tabs3 = $user->where("statu",2)->limit(4)->order(['update_time' => 'desc'])->select();
		//顶部小方块，左，右
		$box1 = Db::name('win')->where("id",1)->find();
		$box2 = Db::name('win')->where("id",2)->find();
		//获取的所有数据存入数组一并调用
		return ["idata"=>$idata,"data"=>$data,"all"=>$all,"column"=>$column,"ipage"=>$ipage,"sum"=>$sum,"diary"=>$diary,"blog"=>$blog,"cment"=>$cment,"mend"=>$mend,"link"=>$link,"tabs1"=>$tabs1,"tabs2"=>$tabs2,"tabs3"=>$tabs3,"box1"=>$box1,"box2"=>$box2];
	}
	public function in(){
		$data = $this->data();
		dump($data["all"]);
	}
	public function time(){
		$user = new Hd();
		$call = $user->IndexData();
		$this->assign('call',$call);
		return $this->fetch();
	}
	public function tags(){
		$user = new Hd();
		$call = $user->IndexData();
		$this->assign('call',$call);
		return $this->fetch();
	}
	public function web($id){
		$user = db('hd');
		
	    $data = $user->where("id",$id)->find();
	    //判断是否已经软删除
	    if($data["delete_time"]!=null){
	        return $this->fetch("null");
	    }
		//获取帖子对应ID的内容
		$hd = $user->where("id",$id)->find();
		
		$req = Request::instance();
		
		$ip = $req->ip();
		
		$time = date("Y-m-d H:i:s",time());
		
		if(!(Cookie::has($id))){
			
			Cookie::set($id,time(),300);
			//进入浏览量加一
			//$index = Hd::where("id",$id)->find();
			//Hd::where('id',$id)->update(['fkl' => ($index["fkl"] + 1)]);
			Hd::where('id',$id)->setInc('fkl');
			if(!$hd){
				
			return $this->fetch("null");
			
			}else{
				
				$nr = "IP：".$ip."在[".$time."]访问了标题为《".$hd['title']."》的文章";
				
				$rz = ["title"=>"文章访问记录","nr"=>$nr,"time"=>$time,"ip"=>$ip];
				
				Db::name('rz')->insert($rz);
			}
			
		}
		//传入页面
		$this->assign('hd',$hd);
		$web = new Hd();
		$call = $web->IndexData();
		$this->assign('call',$call);
		return $this->fetch();
	}
	public function login(){
		return $this->fetch();
	}
	public function stas(){
		$get = input("get.name");
		$data = $this->data();
		
		if(!$get){
			$a = array_keys($data);
			dump($a);
			echo "《临时查询系统》以上为所有可查询字段键名<br>查询类型：GET<br>参数：name<br>请输入您的参数名";
			echo "<form><input type='text' name='name'><input type='submit' value='查询'></form>";
		}else
		{
		    echo json_encode($data[$get]);
			/*print_r("<a href='javascript:history.go(-1);'>向上一页</a><br>参数名：".$get."   数据如下<br>");
			dump($data[$get]);*/
		}
	}
	public function cs(){
	    //获取数据库有多少表
	    //$a = Db::query("show tables");
	    //$a = array_column($a, 'Tables_in_moleier');
	    
           $value = [ 
                "left_xz"    => "what is that",
            ];
     
        //$this->setconfig("config",$value);
       	//$fileurl = APP_PATH ."config.php";
        //$string = file_get_contents($fileurl);
        $a = config("database");
        echo $a["hostname"];
        dump($a);
        //dump($string);
        //dump(config());
	    return;
		$a = input("get.nr");
		$all = Db::name('hd')->where('js|title|bk|bq','like','%'.$a.'%')->select();
		echo "<form><input type='text' name='nr'><input type='submit' value='查询'></form>";
		dump($all);
	}
		public function ly(){
		    return $this->fetch();
		}
	public function search(){
	    $user = new Hd();
		$call = $user->IndexData();
		$this->assign('call',$call);
		$get = input("get.text");
		$data = $this->data();
		$search = Db::name('hd')->where('js|title|bk|bq','like','%'.$get.'%')->select();
		$this->assign('get',$get);
		$this->assign('text',$search);
		$this->assign('column',$data["column"]);
		$this->assign('all',$data["all"]);
		$this->assign('count',count($search));
		return $this->fetch();
	}
	//发件给站长
	public function email(){
		return $this->fetch();
	}
	public function alt(){
	    echo $this->get();
		echo "主控制器测试";
	}
	public function ned(){
		return $this->fetch();
	}
	public function lt(){
		echo php_uname('s');
		echo php_uname('r');
		echo PHP_VERSION;
		echo php_sapi_name();
		echo GetHostByName($_SERVER['SERVER_NAME']);
		echo $_SERVER['SERVER_SOFTWARE'];
	//	phpinfo();
		echo THINK_VERSION;
		echo $_SERVER['HTTP_ACCEPT_LANGUAGE'];
		echo $_SERVER['HTTP_HOST'];
		//return $this->fetch();
	}
	//登录处理
	public function check()
	{
		$date = input('post.');
		$req = Request::instance();
		$ip = $req->ip();
		$time = date("Y-m-d-H:i:s",time());
		$data1 = Db::name('user')->where('name',$date['name'])->find();
		$data2 = Db::name('user')->where('password',$date['password'])->find();
		$user = $date['name'];
		$pass = $date['password'];
		if(!$data1){
			echo "用户名不存在";
			die;
		}
		if(!$data2){
			echo "密码错误";
			die;
		}
		if($data1['yh'] != "站长"){
			echo "吊毛！你不是站长禁止入内";
			die;
		}
		$pass = md5($pass);
			Cookie::set('username',$user,3600*12);
			Cookie::set('password',$pass,3600*12);
			Cookie::set('timestamp',time(),3600*12);
	    	/*$bq = Db::name('rz')->where("title","登陆记录")->column('ip');
	    	if($bq){
	    	$bq = array_count_values($bq);
	    	$key = array_search(max($bq),$bq);
	    	if($key!=$ip){
	    	    $nr = "登陆异常IP：".$ip."，不是常用IP！";
	    	}else{
	    	    $nr = "登陆正常";
	    	}
	    	}else{
	    	    $nr = "登陆正常";
	    	}*/
	    	$nr = "[".$time."]登陆成功,IP：".$ip;
			$data = ["title" => "登陆记录","ip" => $ip,"time" =>$time,"nr" =>$nr];
			Db::name('rz')->insert($data);
			$this->success('登陆成功', '/admin');
	}
	public function foot()
	{
	    $id = input("post.id");
	    $data = Db::name("feedback")->where("id",$id)->find();
	    if($data){
	        return $data;
	    }else{
	        return "数据错误";
	    }
	    
	}
	public function editing()
	{
	    $edit = input("post.");
	    $id = input("post.id");
	    $data = Db::name("win")->where("id",$id)->update($edit);
	    if($data){
	        echo "修改成功";
	    }else{
	        print_r($edit);
	    }
	}
	public function getajax()
	{
	    $id = input("post.id");
	    $data = Db::name("win")->where("id",$id)->find();
	    if($data){
	        echo json_encode($data);
	    }else{
	        echo "获取失败";
	    }
	}
	//首页盒子1
	public function box1(){
	    $data = Db::name("win")->where("id",1)->find();
		return $data["code"];
	}
	//首页盒子2
	public function box2(){
		$data = Db::name("win")->where("id",2)->find();
		return $data["code"];
	}
	public function jk(){
	     $udata = new Udata();
	     
		$ud = $udata->udata();
		echo json_encode($ud);
	}
	public function postemail(){
	    $data = input("post.");
    	$req = Request::instance();
		$ip = $req->ip();
	    $add = ["ip" => $ip];
	    $data = array_merge($data,$add);
	    $user = new Feed($data);
		$true = $user->allowField(true)->save();
	    if($true){
	        echo "反馈已提交";
	    }else{
	        echo "反馈提交失败";
	    }
	}
	public function tencent(){
	    return $this->fetch();
	}
	public function menu($name=""){
	    
	    $table = db("column");
	    $arr = array();
	    $arr2 = array();
	    $column = $table->where("sid",2)->select();
	    foreach ($column as $value) {
	        array_push($arr,$value["id"]);
	    }
	    foreach ($arr as $val) {
	       $data = $table->where("fn",$val)->select();
	       $arr2[$val] = $data;
	    }
	    
	    $web = new Hd();
	    
		$call = $web->IndexData();
		
	    if($name==""){
	        
	        $lan = "全部文章";
	        
	        $NewData = Hd::order(['time' => 'desc'])->paginate(15);
	        
	    }else{
	        
	        $eng = $table->where("url","/menu/".$name)->find();
	        
	        $lan = $eng["title"];
	        
	        $NewData = Hd::where("bk",$lan)->order(['update_time' => 'desc'])->paginate(15);
	    }
	    
		
		$page = $NewData->render();
		$this->assign('data',$NewData);
		$this->assign('page',$page);
		$this->assign('call',$call);
		$this->assign('name',$lan);
		if(!$data){
		    return $this->fetch("null");
		}
	    return $this->fetch();
	}
	public function up(){
	    return $this->fetch();
	}
	public function upload(){
	    $file = request()->file('img');
        $info = $file->rule('uniqid')->validate(['ext'=>'jpg,png,gif'])->move('images/post/content/');
        if($info){
        	$src = "/images/post/content/".$info->getFilename();
        }else{
        	echo $file->getError();
        }
        echo $src;
	}
	public function en(){
	    /*$data = "我是小洲";
	    echo "原文：".$data."<br>";
	    echo "转换首拼音：".$this->ensg($data);*/
	    return $this->fetch();
	}
	public function keyp(){
	    $txt = input("get.txt");
	    $cip = input("get.cip");
	    $txt2 = input("get.txt2");
	    $cip2 = input("get.cip2");
	    $txt3 = input("get.txt3");
	    //base64_encode 加密
	    if($txt){
	        echo base64_encode($txt);
	    }
	    //base64_encode 解密
	    if($cip){
	       echo base64_decode($cip);
	    }
	    //urlencode 加密
	    if($txt2){
	        echo urlencode($txt2);
	    }
	    //urlencode 解密
	    if($cip2){
	       echo urldecode($cip2);
	    }
	    //md5 加密
	    if($txt3){
	       echo md5($txt3);
	    }
	}
	//下载文件
	public function download(){
        //文件名
        $filename = input("get.name");
        // 修改这一行设置你的文件下载目录
        $download_path = "plug/";
         
        // 创建文件下载路径
        $file = $download_path.$filename;
         
        // 判断文件是否存在
        if(!file_exists($file)) return "文件不存在";
         
        //  文件类型，作为头部发送给浏览器
        $type = filetype($file);
         
        // 获取时间和日期
        $today = date("F j, Y, g:i a");
        $time = time();
         
        // 发送文件头部
        header("Content-type: $type");
        header("Content-Disposition: attachment;filename=$filename");
        header("Content-Transfer-Encoding: binary");
        header('Pragma: no-cache');
        header('Expires: 0');
        // 发送文件内容
        set_time_limit(0);
        readfile($file);
	}
	public function leaving(){
	    $data = input("get.");
        $callback = input("get.callback");

	        if($data["content"]==""){
	            echo $callback."(".json_encode("数据不能为空！").")"; 
	            die;
	        }

    	$req = Request::instance();
		$ip = $req->ip();
	    $arr = [
	        "content" => $data["content"],
	        "time" => $data["time"],
	        "ip" => $ip
	        ];
	    $lt = Db::name("leaving")->insert($arr);
	    
	    if($lt){
	        echo $callback."(".json_encode("留言成功").")"; 
	    }else{
	        echo $callback."(".json_encode("留言失败").")"; 
	    }
	}
	public function get_leaving(){
	    $callback = input("get.callback");
	            
	    $table = Db::name("leaving")->select();
	    
	    echo $callback."(".json_encode($table).")"; 
	}
public function get($url="images"){
    $url = "./".$url;
    $sl=0;//造一个变量，让他默认值为0;
    $arr = glob($url);//把该路径下所有的文件存到一个数组里面;
    foreach ($arr as $v)//循环便利一下，吧数组$arr赋给$v;
    {
        if(is_file($v))//先用个if判断一下这个文件夹下的文件是不是文件，有可能是文件夹;
        {
            $sl++;//如果是文件，数量加一;
        }
        else
        {
            $sl += $this->get($v."/*");//如果是文件夹，那么再调用函数本身获取此文件夹下文件的数量，这种方法称为递归;
        }
    }
    return $sl;//当这个方法走完后，返回一个值$sl,这个值就是该路径下所有的文件数量;
    }
    public function null(){
        $user = new Hd();
		$call = $user->IndexData();
		$this->assign('call',$call);
        return $this->fetch();
    }
    function setconfig($file,$data){
        if (is_array($data)){
        	$fileurl = APP_PATH .$file.".php";
            $string = file_get_contents($fileurl); //加载配置文件
        	foreach ($data as $key => $value) {
        		$pats = '/\'' . $key . '\'(.*?)\',/';
        		$reps = "'". $key. "'". "			=> " . "'".$value ."',";
        		$string = preg_replace($pats, $reps, $string); // 正则查找然后替换
        	}
        	file_put_contents($fileurl, $string); // 写入配置文件
            return true;
        }else{
            return false;
        }
    }
}
