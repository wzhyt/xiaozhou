<?php
namespace app\index\controller;
class Boss
{
	public function index()
	{
		echo "空间命名1";
	}
}