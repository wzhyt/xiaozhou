<?php
namespace app\index\controller;
use think\Controller;
use think\Cookie;
use think\Db;
class Base extends Controller
{
	public function _initialize()
	{
		
		if(Cookie::has('username')&&Cookie::has('password')&&Cookie::has('timestamp')) {
			$user = Cookie::get('username');
			$pass = Cookie::get('password');
			$time = Cookie::get('timestamp');
			$data = Db::name('user')->where("name",$user)->find();
			if($data){
				if($pass != md5($data["password"])){
				    Cookie::delete('username');
					Cookie::delete('password');
					Cookie::delete('timestamp');
					$this->error('非法错误！','/login');
				}
			}else{
			    Cookie::delete('username');
				Cookie::delete('password');
				Cookie::delete('timestamp');
				$this->error('你还没有登陆哦！','/login');
			}
		}else{
		    Cookie::delete('username');
			Cookie::delete('password');
			Cookie::delete('timestamp');
			$this->error('你还没有登陆哦！','/login');
		}
	}
}