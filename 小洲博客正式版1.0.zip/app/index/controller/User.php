<?php
namespace app\index\controller;
use think\Controller;
use think\Request;
use think\Db;
use think\db\Query;
use think\Cookie;
use think\Session;
use think\Config;
use app\index\validate\Hd as HdValidate;
use app\index\controller\Index as Index;
use app\index\model\Udata as Udata;
use app\index\model\Hd as Hd;

class User extends Base
{
	public function index()
	{
		return $this->fetch();
	}
	//后台管理
	public function admin($name="admin")
	{   
	    //实例化命名空间
	    $udata = new Udata();
		//执行命名空间函数udata
		$ud = $udata->udata();
		$arr = ["file" => ($this->get("images") + $this->get("music") + $this->get("video")),"database" => config("database")];
		$ud = array_merge($ud,$arr);
		//页面传值
		$this->assign('ud',$ud);
	   	$this->assign('name',$name);
		return $this->fetch($name);
	}
	public function post()
	{
		return $this->fetch();
	}
	public function pro()
	{
	    $data = input("post.");
	    $file = request()->file('img');
    if($file){
        $info = $file->rule('uniqid')->validate(['ext'=>'jpg,png,gif'])->move('images/post/');
        if($info){
        	$src = "/images/post/".$info->getFilename();
        }else{
        	echo "图片上传错误".$file->getError();
        }
    }else{
    		$src = "/images/post/null.png";
    }
		$name = cookie('username');
		$ud = Db::name('user')->where('name',$name)->find();
		$time = date("Y-m-d",time());
		$ensg = $this->ensg($data["bk"]);
		$url = '/menu/'.$ensg;
		$add = ['outhorimg' => $ud['img'],'name' => $ud['nc'],'img' => $src,'url' => $url];
		$val = new HdValidate();
		if (!$val->check($data)) {
			$this->error($val->getError());
			exit;
		}
		$data = array_merge($data,$add);
		$ret = new Hd($data);
		$ret->save();
		if ($ret) {
			echo json_encode(["msg" => "发布成功"]);
		} else {
			echo json_encode(["msg" => "发布失败，请稍后再试"]);
		}
	}
	public function echange(){
	    $data = input("post.");
	    $file = request()->file('img');
    if($file){
        $info = $file->rule('uniqid')->validate(['ext'=>'jpg,png,gif'])->move('images/post/');
        if($info){
        	$src = "/images/post/".$info->getFilename();
        }else{
        	echo "图片上传错误".$file->getError();
        }
    }else{
    		$src = Db::name("hd")->where("id",$data["id"])->find();
    		$src = $src["img"];
    }
		
		$name = cookie('username');
		$ud = Db::name('user')->where('name',$name)->find();
		$time = date("Y-m-d",time());
		$ensg = $this->ensg($data["bk"]);
		$url = '/menu/'.$ensg;
		$add = ['outhorimg' => $ud['img'],'name' => $ud['nc'],'img' => $src,'url' => $url];
		$val = new HdValidate();
		if (!$val->check($data)) {
			$this->error($val->getError());
			exit;
		}
		$data = array_merge($data,$add);
		$ret = Hd::where("id",$data["id"])->update($data);
		if ($ret) {
			echo "修改成功";
		} else {
		    trigger_error('修改失败');
		}
	}
	public function ensg($str){
		$sum = array();
		$arr = preg_split("//u", $str, -1, PREG_SPLIT_NO_EMPTY);
		for($i = 0; $i < count($arr); $i++) {
			$s1=iconv('UTF-8','gb2312',$arr[$i]);
			$s2=iconv('gb2312','UTF-8',$s1);
			$s=$s2==$arr[$i]?$s1:$arr[$i];
			$asc=ord($s{0})*256+ord($s{1})-65536;
			if($asc>=-20319&&$asc<=-20284) array_push($sum,'a');
			if($asc>=-20283&&$asc<=-19776) array_push($sum,'b');
			if($asc>=-19775&&$asc<=-19219) array_push($sum,'c');
			if($asc>=-19218&&$asc<=-18711) array_push($sum,'d');
			if($asc>=-18710&&$asc<=-18527) array_push($sum,'e');
			if($asc>=-18526&&$asc<=-18240) array_push($sum,'f');
			if($asc>=-18239&&$asc<=-17923) array_push($sum,'g');
			if($asc>=-17922&&$asc<=-17418) array_push($sum,'h');
			if($asc>=-17417&&$asc<=-16475) array_push($sum,'j');
			if($asc>=-16474&&$asc<=-16213) array_push($sum,'k');
			if($asc>=-16212&&$asc<=-15641) array_push($sum,'l');
			if($asc>=-15640&&$asc<=-15166) array_push($sum,'m');
			if($asc>=-15165&&$asc<=-14923) array_push($sum,'n');
			if($asc>=-14922&&$asc<=-14915) array_push($sum,'o');
			if($asc>=-14914&&$asc<=-14631) array_push($sum,'p');
			if($asc>=-14630&&$asc<=-14150) array_push($sum,'q');
			if($asc>=-14149&&$asc<=-14091) array_push($sum,'r');
			if($asc>=-14090&&$asc<=-13319) array_push($sum,'s');
			if($asc>=-13318&&$asc<=-12839) array_push($sum,'t');
			if($asc>=-12838&&$asc<=-12557) array_push($sum,'w');
			if($asc>=-12556&&$asc<=-11848) array_push($sum,'x');
			if($asc>=-11847&&$asc<=-11056) array_push($sum,'y');
			if($asc>=-11055&&$asc<=-10247) array_push($sum,'z');
		}
		$let = implode("",$sum);
		return $let; 
	}
	public function datas(){
	    $get = input("get.title");
	    $id = input("get.id");
	    $seeding = Db::name('seeding');
	    $sedd = $seeding->where("id",$id)->update(['title' => $get]);
	    if($sedd){
	        echo "更改成功";
	    }else{
	        echo "更改失败！";
	    }
	}
	public function src(){
	    $file = request()->file('img');
        // 移动到框架应用根目录/public/uploads/ 目录下
        if($file){
             $info = $file->rule('uniqid')->validate(['ext'=>'jpg,png,gif'])->move('images/seeding/');
            if($info){
                // 成功上传后 获取上传信息
                $img_src = '/images/seeding/'.$info->getSaveName();
            }else{
                // 上传失败获取错误信息
                $this->error($file->getError());
            }
        }
	    $id = input("post.id");
	    $title = input("post.title");
	    if($file){
	        $arr = ['src' => $img_src,"title" => $title];
	    }else{
	        $arr = ["title" => $title];
	    }
	    $sedd = db("seeding")->where("id",$id)->update($arr);
	    if($sedd){
	        if($file){
	            echo $img_src;
	        }else{
	            echo "修改成功！";
	        }
	    }else{
	        echo "更改失败！";
	    }
	}
	public function seed(){
        $id = input("get.id");
        $data = Db::name("seeding")->where("id",$id)->find();
        if($data){
            echo json_encode($data);
        }else{
            echo "数据错误"; 
        }
    }
	public function add(){
	    $file = request()->file('img');
        // 移动到框架应用根目录/public/uploads/ 目录下
        if($file){
             $info = $file->rule('uniqid')->validate(['ext'=>'jpg,png,gif'])->move('images/seeding/');
            if($info){
                // 成功上传后 获取上传信息
                $img_src = '/images/seeding/'.$info->getSaveName();
            }else{
                // 上传失败获取错误信息
                $this->error($file->getError());
            }
        }else{
            $img_src = "/images/null.png";
        }
        $title = input("post.title");
	    $sedd = Db::name("seeding")->insert(["title" => $title,"src" => $img_src]);
	    if($sedd){
	        echo json_encode(["title" => $title,"src" => $img_src]);
	    }else{
	        echo "更改失败！";
	    }
	}
	public function cs(){
	    $udata = new Udata();
	    dump($udata->udata());
	    die;
		//执行命名空间函数udata
		$ud = $udata->getd("darr");
		echo json_encode($ud);
	    die;
		//实例化命名空间
		//$class = new Index();
		//调用命名空间
		//$lt = $class->data();
		//dump($lt);
		$user = Db::name('hd');
		$year = date("Y",time());
		$arr = array();
		$darr = array();
		for($i=1;$i<=12;$i++){
		    array_push($arr,date('t', strtotime($year . '-' . $i . '-01')));
		}
		dump($arr);
		for($x=0;$x<12;$x++){
		   	$a = $user->where('create_time','between time',[$year.'-'.($x+1).'-1',$year.'-'.($x+1).'-'.$arr[$x].''])->select();
		   	array_push($darr,count($a));
		   	
		}
		
	}
	//全局设置修改
	public function allsz(){
	    $data = input("post.");
	    $true = Db::name('allsz')->where('id',1)->update($data);
	    if($true){
	        echo "修改成功";
	    }else{
	        echo "修改失败";
	    }
	}
	
	public function all(){
	    $udata = new Udata();
		//执行命名空间函数udata
		$ud = $udata->udata();
		dump($ud["pagedata"]);
	}
	public function off(){
	    $user = db("allsz");
	    $data = $user->where("id",1)->find();
	    if($data["statu"]==1){
	        $xj = $user->where("id",1)->update(['statu' => 0]);
	        if($xj){
	            echo "网站已关闭";
	        }else{
	            echo "网站关闭失败";
	        }
	    }else{
	        $hf = $user->where("id",1)->update(['statu' => 1]);
	        if($hf){
	            echo "网站已开启";
	        }else{
	            echo "网站开启失败";
	        }
	    }
	}
	public function dele(){
	    $id = input("post.id");
		$data = Hd::destroy($id,true);
	    if($data){
	        echo "删除成功";
	    }else{
	        echo "删除失败";
	    }
	}
	public function SelectChange(){
	    $id = input("post.id");
	    $user = db("hd");
	    $data = $user->where("id",$id)->find();
	    if($data["delete_time"]==null){
	        $xj= Hd::destroy($id);
	        if($xj){
	            echo "下架成功";
	        }else{
	            echo "下架失败";
	        }
	    }else{
	        $hf = $user->where("id",$id)->update(['delete_time' => null]);
	        if($hf){
	            echo "恢复正常";
	        }else{
	            echo "恢复失败";
	        }
	    }
	}
    //获取文件夹文件数量
    public function get($url){
        $url = "./".$url;
        $sl=0;//造一个变量，让他默认值为0;
        $arr = glob($url);//把该路径下所有的文件存到一个数组里面;
        foreach ($arr as $v)//循环便利一下，吧数组$arr赋给$v;
        {
            if(is_file($v))//先用个if判断一下这个文件夹下的文件是不是文件，有可能是文件夹;
            {
                $sl++;//如果是文件，数量加一;
            }
            else
            {
                $sl += $this->get($v."/*");//如果是文件夹，那么再调用函数本身获取此文件夹下文件的数量，这种方法称为递归;
            }
        }
        return $sl;//当这个方法走完后，返回一个值$sl,这个值就是该路径下所有的文件数量;
    }
    public function comp(){
        $id = input("post.id");
        $user = Db::name("hd")->where("id",$id)->find();
        echo json_encode($user);
    }
    public function gets(){
        return $this->fetch();
    }
	public function eit(){
	    Cookie::delete('username');
		Cookie::delete('password');
		Cookie::delete('timestamp');
		$this->success('退出成功', '/login');
	}
}