<?php
namespace app\index\model;
use think\Model;
use think\Db;
use think\Request;
use think\Cookie;
use think\Session;
use app\index\model\Hd as Hd;
//后台数据获取
class udata extends Model
{
    public function udata(){
        //网站基本信息连接
        $sz = Db::name('allsz')->find();
        //IP记录
        $yip = Db::name('rz')->where("title","登陆记录")->limit(5)->order(['time' => 'desc'])->select();
        //日志信息
        $rz = Db::name('rz')->limit(50)->order(['time' => 'desc'])->select();
        //网站信息与服务器信息
        //服务器操作系统
        $uname_s = php_uname('s');
        
        //服务器版本
		$uname_r = php_uname('r');
	
		//PHP版本
		$von = PHP_VERSION;
		
		//服务器运行方式
		$name = php_sapi_name();
		
		//服务器IP
		$serverip = GetHostByName($_SERVER['SERVER_NAME']);
		
		//web服务器
		$server = $_SERVER['SERVER_SOFTWARE'];
		
		//框架版本
		$think = "ThinkPHP ".THINK_VERSION;
		
		//系统语言
		$lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
		$lang  =  strstr ( $lang ,  ',' ,  true );
		
		//网站域名
		$host = $_SERVER['HTTP_HOST'];
		
		//连续获取hd表
		$user = db('hd');
		//当前年
		$year = date("Y",time());
		//存储每个月的天数
		$arr = array();
		//存储每个月发布的文章
		$darr = array();
		for($i=1;$i<=12;$i++){
		    array_push($arr,date('t', strtotime($year . '-' . $i . '-01')));
		}
		for($x=0;$x<12;$x++){
		   	$a = $user->where('create_time','between time',[$year.'-'.($x+1).'-1',$year.'-'.($x+1).'-'.$arr[$x].''])->select();
		   	array_push($darr,count($a));
		}
		//消息通知
		$foot = Db::name('feedback')->order(['create_time' => 'desc'])->select();
		//轮播图获取
		$seeding = Db::name('seeding')->select();
		//首页自定义图文
		$win = Db::name('win')->select();
		//后台文章分页
		$pagedata =  Db::name("hd")->order(['create_time' => 'desc'])->paginate(10);
		//获取今日访客量
		$times = time();
		$time = date('Y-m-d',$times);
		$time_d = date('Y-m-d',$times + 86400);
		$visit = Db::name("rz")->where("title","文章访问记录")->whereTime('time','between',[$time,$time_d])->select();
	    $visit = count($visit);
	    //总访客量
	    $AllVisit = Db::name("hd")->sum("fkl");
	    //总发帖
	    $count = $user->count("id");
		//返回为数组形式
		return [
		    "sz"       => $sz,
		    "rz"       => $rz,
		    "yip"      => $yip,
		    "uname_s"  => $uname_s,
		    "uname_r"  => $uname_r,
		    "von"      => $von,
		    "name"     => $name,
		    "serverip" => $serverip,
		    "server"   => $server,
		    "think"    => $think,
		    "lang"     => $lang,
		    "host"     => $host,
		    "darr"     => $darr,
		    "foot"     => $foot,
		    "seeding"  => $seeding,
		    "win"      => $win,
		    "pagedata" => $pagedata,
		    "visit"    => $visit,
		    "AllVisit" => $AllVisit,
		    "count"    => $count
		    ];
    }

    public function getd($get){
        $data = $this->udata();
        return $data[$get];
    }
}