<?php
namespace app\index\model;
use think\Model;
use think\Db;
use think\Request;
use traits\model\SoftDelete;
class Hd extends Model
{
	use SoftDelete;
	protected $createTime = 'create_time';
	protected $updateTime = 'update_time';
	protected static $deleteTime = 'delete_time';
	public function IndexData(){
	    //系统设置
	   	$all = Db::name('allsz')->find();
		/*
			statu类型
			1：博客日记
			4：个人博客搭建
			mend类型
			0：默认不推荐
			1：站长推荐
			cment类型
			
		*/
		//文章数据库持续链接
		$user = db('hd');
		//获取十条数据分页显示
		$data = Hd::order(['create_time' => 'desc'])->paginate(10);
		//获取全部数据
		$datas = Hd::order(['create_time' => 'desc'])->select();
		//选项卡1·博客日记
		$tabs1 = Hd::where("statu",1)->limit(4)->order(['create_time' => 'desc'])->select();
		//选项卡2·友情链接
		$tabs2 = Db::name('link')->limit(4)->select();
		//选项卡3·个人博客搭建
		$tabs3 = Hd::where("statu",4)->limit(4)->order(['create_time' => 'desc'])->select();
		//轮播图
		$seeding = Db::name('seeding')->select();
		//顶部小方块
		$box1 = Db::name('win')->where("id",1)->find();
		$box2 = Db::name('win')->where("id",2)->find();
		//首页数据分页
		$page = $data->render();
		//统计帖子数
		$sum = Hd::count();
		//博客日记
		$diary = Hd::limit(3)->where("statu",1)->order(['create_time' => 'desc'])->select();
		//个人博客搭建
		$blog = Hd::limit(3)->where("statu",4)->order(['create_time' => 'desc'])->select();
		//浏览最多
		$cment = Hd::limit(4)->order('fkl desc')->select();
		//站长推荐
		$mend = Hd::limit(6)->where("mend",1)->order(['create_time' => 'desc'])->select();
		//友情链接
		$link = Db::name('link')->limit(3)->select();
		//菜单
		$column = Db::name('column')->select();
		//标签统计
		$bq = Hd::column('bq');
		//统计重复次数
		$bq = array_count_values($bq);
		//右侧栏站长推荐
		$recommend = Hd::limit(6)->where("mend",1)->order(['create_time' => 'desc'])->select();
		return [
		    "all"       => $all,
		    "data"      => $data,
		    "datas"     => $datas,
		    "tabs1"     => $tabs1,
		    "tabs2"     => $tabs2,
		    "tabs3"     => $tabs3,
		    "seeding"   => $seeding,
		    "box1"      => $box1,
		    "box2"      => $box2,
		    "page"      => $page,
		    "sum"       => $sum,
		    "diary"     => $diary,
		    "blog"      => $blog,
		    "cment"     => $cment,
		    "mend"      => $mend,
		    "link"      => $link,
		    "column"    => $column,
		    "bq"        => $bq,
		    "recommend" => $recommend,
		    ];
	}
}