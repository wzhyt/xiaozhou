CREATE TABLE IF NOT EXISTS `tk_allsz` (
  `id` int(11) DEFAULT NULL,
  `title` char(50) DEFAULT NULL DEFAULT '小洲博客' COMMENT '网站标题',
  `opentime` int(20) DEFAULT NULL,
  `Nickname` char(255) DEFAULT NULL COMMENT '昵称',
  `Occupation` char(255) DEFAULT NULL COMMENT '职业',
  `Living` char(255) DEFAULT NULL COMMENT '现居',
  `Email` char(255) DEFAULT NULL COMMENT '邮箱',
  `Signature` char(255) DEFAULT NULL COMMENT '个性签名',
  `Vice` char(255) DEFAULT NULL COMMENT '提示签名',
  `QQ` int(10) DEFAULT NULL COMMENT 'QQ',
  `Record` char(255) DEFAULT NULL,
  `PoliceRecord` char(255) DEFAULT NULL,
  `Footer1` char(255) DEFAULT NULL DEFAULT '1、本站为个人博客，全部页面与功能都由小洲完成，个人可以免费使用，但是未经许可不得用于任何商业目的。' COMMENT '页脚1',
  `Footer2` char(255) DEFAULT NULL DEFAULT '2、所有文章转载前请标注转载地址。' COMMENT '页脚2',
  `Footer3` char(255) DEFAULT NULL DEFAULT 'Copyright ©    个人博客    版权所有' COMMENT '页脚3',
  `host` varchar(255) DEFAULT NULL DEFAULT 'smtp.qq.com',
  `port` int(11) DEFAULT NULL DEFAULT '465',
  `coding` varchar(255) DEFAULT NULL DEFAULT 'UTF-8',
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `statu` int(11) DEFAULT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tk_column` (
  `id` int(11) DEFAULT NULL,
  `title` char(50) DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `fn` int(11) DEFAULT NULL DEFAULT '0' COMMENT '是id为谁的二级菜单',
  `sid` int(11) DEFAULT NULL DEFAULT '0' COMMENT '判断是否为二级菜单',
  `delete_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `tk_column` (`id`, `title`, `url`, `fn`, `sid`, `delete_time`, `create_time`, `update_time`) VALUES
(1, '博客人生', '/menu/bkrs', 0, 2, NULL, now(), now()),
(2, '博客日记', '/menu/bkrj', 1, 0, NULL, now(), now()),
(3, '博客日志', '/menu/bkrz', 1, 0, NULL, now(), now()),
(4, '个人博客搭建', '/menu/grbkdj', 0, 0, NULL, now(), now()),
(5, '实用工具', '/menu/sygj', 0, 2, NULL, now(), now()),
(6, '友情链接', '/menu/yqlj', 0, 0, NULL, now(), now()),
(7, '插件', '/menu/cj', 5, 0, NULL, now(), now()),
(8, '课堂作业', '/menu/ktzy', 1, 0, NULL, now(), now());

CREATE TABLE IF NOT EXISTS `tk_feedback` (
  `id` int(11) DEFAULT NULL,
  `name` char(50) DEFAULT NULL,
  `tel` char(20) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `xx` text DEFAULT NULL,
  `ip` char(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tk_hd` (
  `id` int(11) DEFAULT NULL,
  `title` char(50) DEFAULT NULL COMMENT '标题',
  `content` text DEFAULT NULL COMMENT '内容',
  `js` char(255) DEFAULT NULL DEFAULT '暂无简述！' COMMENT '简单描述',
  `url` char(255) DEFAULT NULL,
  `mend` int(11) DEFAULT NULL DEFAULT '0' COMMENT '1为站长推荐',
  `statu` int(2) DEFAULT NULL DEFAULT '0' COMMENT '状态类型',
  `name` char(50) DEFAULT NULL DEFAULT '小洲' COMMENT '发布人',
  `bk` char(50) DEFAULT NULL COMMENT '所属栏目',
  `ebk` char(255) DEFAULT NULL,
  `bq` char(10) DEFAULT NULL COMMENT '标签',
  `fkl` int(11) DEFAULT NULL DEFAULT '0' COMMENT '访客量',
  `pl` int(255) DEFAULT NULL DEFAULT '0' COMMENT '评论条数',
  `img` char(255) DEFAULT NULL DEFAULT '/images/null.png' COMMENT '图片显示',
  `outhorimg` char(255) DEFAULT NULL COMMENT '作者头像',
  `delete_time` datetime DEFAULT NULL COMMENT '软删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tk_hd` (`id`, `title`, `content`, `js`, `url`, `mend`, `statu`, `name`, `bk`, `ebk`, `bq`, `fkl`, `pl`, `img`, `outhorimg`, `delete_time`, `create_time`, `update_time`) VALUES
(1, '博客搭建成功！', '<p class="ql-align-center">欢迎你加入我的博客小世界，跟我一起记录生活中的美好吧~<br>如需删除此文章请登录后台<a target="_blank" href="http://blog.wzhyt.cn/admin/post">文章管理</a>进行删除</p>', '博客搭建成功！快来记录美好生活吧~', '/menu/bkrj', 1, 1, '小洲', '博客日记', NULL, '博客', 0, 0, '/images/post/Welcome.jpg', '/images/xz.jpg', NULL, now(), now());


CREATE TABLE IF NOT EXISTS `tk_link` (
  `id` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `bk` char(255) DEFAULT NULL DEFAULT '友情链接',
  `img` char(255) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `js` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tk_rz` (
  `id` int(11) DEFAULT NULL,
  `title` char(50) DEFAULT NULL,
  `nr` text DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `ip` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tk_seeding` (
  `id` int(11) DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `src` char(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tk_seeding` (`id`, `title`, `src`) VALUES
(1, '鬼刀背景图', '/images/seeding/gd2.jpg'),
(2, '第2张', '/images/seeding/bk2.jpg'),
(3, '第3张', '/images/seeding/lt.jpg'),
(4, '第4张', '/images/seeding/bk1.jpg');

CREATE TABLE IF NOT EXISTS `tk_user` (
  `id` int(11) DEFAULT NULL COMMENT '用户唯一ID',
  `name` char(255) DEFAULT NULL COMMENT '用户名',
  `nc` char(50) DEFAULT NULL DEFAULT '小白' COMMENT '昵称',
  `password` char(32) DEFAULT NULL COMMENT '当前密码',
  `repassword` char(32) DEFAULT NULL COMMENT '用户初始密码',
  `email` char(50) DEFAULT NULL COMMENT '邮箱',
  `sex` char(10) DEFAULT NULL DEFAULT '男' COMMENT '性别',
  `area` char(255) DEFAULT NULL,
  `qq` char(10) DEFAULT NULL,
  `img` char(255) DEFAULT NULL DEFAULT '/images/xz.jpg' COMMENT '用户头像',
  `rmb` int(255) DEFAULT NULL DEFAULT '100' COMMENT '积分',
  `create_time` datetime DEFAULT NULL COMMENT '注册时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `delete_time` datetime DEFAULT NULL COMMENT '软删除',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `yh` char(30) DEFAULT NULL DEFAULT '普通会员' COMMENT '权限等级',
  `statu` int(10) DEFAULT '1' COMMENT '账号状态'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tk_win` (
  `id` int(11) DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `code` text DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `img` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tk_win` (`id`, `title`, `code`, `url`, `img`) VALUES
(1, '站内文件说明', '<p>此页面需要修改请进入后台管理<br>public文件说明</p>
<dl>
  <dt>CSS</dt>
  <dd>index.css -> 前台基本样式</dd>
  <dd>nav.css -> 导航栏样式</dd>
  <dd>admin.css -> 后台基本样式</dd>
  <dt>JS</dt>
  <dd>index.js-> 前台操作脚本</dd>
  <dd>admin.js -> 后台操作脚本</dd>
  <dd>web.js-> 后台提交数据脚本</dd>
  <dd>window.js-> 悬浮窗、提示、弹窗插件</dd>
  <dt>Email</dt>
  <dd>email.php -> 邮箱接口</dd>
  <dd>function.php -> 邮箱配置文件</dd>
  <dd>接口配置好后如何使用？接口支持GET与POST方式</dd>
  <dd>例：域名/Email/email.php?yx=83154897@qq.com&bt=标题&nr=内容</dd>
  <dt>tap</dt>
  <dd>娱乐游戏 -> 域名/tap即可进入</dd>
</dl>', '/box1', '/images/app/yq.jpg'),
(2, '我的博客小屋', '自定义页面2', '/box2', '/images/app/tk.jpg');

ALTER TABLE `tk_allsz`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_column`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_feedback`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_hd`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_link`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_rz`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_seeding`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_user`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_win`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tk_allsz`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;

ALTER TABLE `tk_column`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;

ALTER TABLE `tk_feedback`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT;

ALTER TABLE `tk_hd`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT;

ALTER TABLE `tk_link`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT;

ALTER TABLE `tk_rz`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT;

ALTER TABLE `tk_seeding`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;

ALTER TABLE `tk_user`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT COMMENT '用户唯一ID',AUTO_INCREMENT=1;

ALTER TABLE `tk_win`
  MODIFY `id` int(11) DEFAULT NULL AUTO_INCREMENT;