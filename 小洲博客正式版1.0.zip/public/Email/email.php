<?php
header("Content-Type:text/html;charset=utf-8");
if(isset($_GET["yx"])||$bt=$_GET["bt"]||$nr=$_GET["nr"]){
$yx=$_GET["yx"];
$bt=$_GET["bt"];
$nr=$_GET["nr"];
}else{
$yx=$_POST["yx"];
$bt=$_POST["bt"];
$nr=$_POST["nr"];
}
require_once("./functions.php");
$flag = sendMail($yx,$bt,$nr);
if($flag){
    echo "发送成功";
}
else
{
echo "发送失败，请检查你的邮箱是否正确\n".$yx;
}
?>