function move(dv,fo){
	var isD = false;
	var x = 0;
	var y = 0;
	var l = 0;
	var t = 0;
	
	window.onmousemove = function(event){
		let even = event || window.event;
		if(!isD){
			return;
		}
		
		
		var nn = even.clientY - (y-t);
		var n = even.clientX - (x-l);
		var ww = $(window).width()-$(dv).width();
		var wh = $(window).height()-$(dv).height();
		if(n>=ww){
			n = n>=ww?ww:n;
		}else{
			n = n<=0?0:n;
		}
		
		if(nn>=wh){
			nn = nn>=wh?wh:nn;
		}else{
			nn = nn<=0?0:nn;
		}
		dv.style.left = n +"px";
		dv.style.top = nn +"px";
		console.log(n + ";" + nn);
	}
//	mdv.onmousedown = function(event){
		$(fo).mousedown(function(event){
		var event = event || window.event;
		x = event.clientX;
		y = event.clientY;
		l = dv.offsetLeft;
		t = dv.offsetTop;
		isD = true;
	}).mouseup(function(){
	//mdv.onmouseup = function(){
		isD = false;
	})
}
//普通弹窗
    function win(text,dome,log){
		if(!text){
			alert("提示内容不能为空！");
			return ;
		}
        dome = dome?dome:"提示";
        $("body").append(`
            <div class="win-layer">
                <div class="win-up">
                    <div class="win-m">
                        <span>${dome}</span>
                        <p>${text}</p>
                    </div>
                    <div class="win-done">
                        <span class="win-exit">确认</span>
                    </div>
                </div>
            </div>
        `);
		$(".win-layer").css({
			'top': '0',
			'left': '0',
			'width': '100%',
			'height': '100%',
			'z-index': '9999',
			'position': 'fixed',
			'background': 'rgba(0, 0, 0, 0.2)',
			'animation-duration': '500ms',
			'text-align': 'center',
			'display': 'none',
		})
		$(".win-up").css({
			'position': 'fixed',
			'min-width': '250px',
			'max-width': '320px',
			'z-index': '9999',
			'background': '#fff',
			'border-radius': '10px',
			'left': '50%',
			'top': '50%',
			'transform': 'translate(-50%, -50%)',
			'animation-duration': '500ms',
			'overflow': 'hidden',
		})
		$(".win-m").css({
			'width': '100%',
			'box-sizing': 'border-box',
			'padding': '15px',
			'border-bottom': '1px solid #eee',
			'color':'#2d3436',
		})
		$(".win-m span").css({
			'font-size': '16px',
			'font-weight': '700',
			'user-select': 'none',
		})
		$(".win-m p").css({
			'margin': '8px 0 0 0',
 			//'user-select': 'none',
		})
		$(".win-done .win-exit").css({
			'display': 'block',
			'width': '100%',
			'line-height': '40px',
			'cursor': 'pointer',
			'user-select': 'none',
			'font-size': '14px',
			'color': '#27ae60',
		})
        $(".win-layer").fadeIn(200);
        $(".win-exit").click(function(){
            $(".win-layer").fadeOut(200,function(){
                if(log){
                    log();
                }
				$(this).remove();
			});
        })
    }
    //提示工具
    function toast(text,time){
        time = time?time:3000;
        $("body").append(`
            <div class="tast">
                <p>${text}</p>
            </div>
        `);
		$(".tast").css({
			"line-height": "1.3",
			"text-align": "center",
			"position": "fixed",
			"max-width": "200px",
			"z-index": "99999",
			"padding": "10px 14px 10px 14px",
			"color": '#fff',
			"background": "#000",
			"border-radius": "5px",
			"left": "50%",
			"top": "50%",
			"font-size": "14px",
			"transform": "translate(-50%, -50%)",
			"display":"none",
		})
        $(".tast").fadeIn(800);
        setTimeout(()=>{
            $(".tast").fadeOut(800,function(){
				$(this).remove();
			});
        },time)
    }