$(function(){
    //站点开关
    $(".total_top>.switch").click(function(){
			off();
		$(".total_top>.switch").toggleClass("sw_on");
	})
    //文章删除
    $(".tabl #PostDel").click(function(){
        if (confirm("一但删除将无法恢复，你确认要删除吗？")==true){
		var index = $(".tabl #PostDel").index(this);
        var id = $(".tabl #PostDel").eq(index).attr("data-id");
        var sid = {
            id: id
        };
        $.ajax({
            url:"/index/user/dele",
            type:"POST",
            data:sid,
            success:function(data){
                win(data);
                if(data=="删除成功"){
                    $(".tabl tr").eq(index+1).remove();
                     setTimeout(function(){
                        history.go(0);
                    },500);
                }
            },
            error:function(xhr,status,error){
                console.log(xhr+"|"+status+"|"+error);
            }
    		 });
    	}
        
    })
    //弹出发布文章界面
    $("#paa").click(function(){
	    $(".putshowdiv").fadeIn();
	})
    //关闭发布文章界面
    $(".putshow #post_esc").click(function(){
        $(".putshowdiv").fadeOut();
    })
    //设置默认不可编辑
    $(".szdiv input[type=text],.szdiv textarea").attr("disabled","disabled");
    //$(".seed_w #seed_txt").eq(s).removeAttr("disabled");
    $("#editing").click(function(){
        //判断是否不可编辑
        if($(".szdiv input[type=text],.szdiv textarea").attr("disabled")!="disabled"){
            //不可编辑
            $(".szdiv input[type=text],.szdiv textarea").attr("disabled","disabled");
        }else{
            //可编辑
            $(".szdiv input[type=text],.szdiv textarea").removeAttr("disabled");
        }
    })
    //编辑发生事件
    var js = {};
    $(".szdiv input[type=text],.szdiv textarea").change(function(){
        $(".prese").fadeIn();
        var arr = new Array();
        $(".szdiv input[type=text],.szdiv textarea").each(function(){
            arr[$(this).attr("name")] = $(this).val();
        })
        //把数组存入json
        for(x in arr){
            js[x] = arr[x];
        }
    })
    $(".prese").click(function(){
        $(this).fadeOut();
        console.log(js)
        ajax("/index/user/allsz","POST",js)
    })
    //打开编辑页面
    $("tbody #change-text").click(function(){
        var id = $("tbody #change-text").index(this) + 1;
        console.log(id)
        if($(".alt").length<1){
            $.ajax({
                    url:"/index/index/getajax",
                    type:"POST",
                    data:{
                        id :id
                    },
                    dataType:'json',
                    success:function(get){
                       $(".righttow").append(`
                            <div class="sbom">
                            <div class="salt">
                                <div class="saltt">
                                    <span class="salt_name">页面编辑</span>
                            		<span id='offn'>×</span>
                                </div>
                                <div class="saltw">
                                    <div class="saltwin">
                                        <button>保存</button>
                                        <input type="text" id="s_title" value="${get.title}" placeholder="标题">
                                    </div>
                                    <textarea spellcheck="false">${get.code}</textarea>
                                </div>
                            </div>
                            </div>
                        `);
        $(".salt").show();
         var alt = document.querySelector(".salt");
         var altt = document.querySelector(".saltt");
         var bom = document.querySelector(".sbom");
        move(alt,altt);
            $("#offn").click(function(){
                dele(bom);
            })
        //执行文本域事件
        textarea();
            //保存事件
            $(".saltwin button").click(function(){
                var vale = $(".saltw textarea").val();
                var title = $("#s_title").val();
                if(title.length<4){
                    win("标题不得少于4个字符");
                    return;
                }else if(vale.length<20){
                    win("内容不得少于20个字符");
                    return;
                }
                var val = {
                    id : id,
                    title : title,
                    code : vale
                }
                ajax("/index/index/editing","POST",val)
            })
                    },
                    error:function(xhr,status,error){
                        console.log(xhr+"|"+status+"|"+error);
                        win("获取失败");
                    }
            		 });
        }
    })
    //显示添加轮播图界面
    //调用悬浮窗函数
    $(".seed_add").click(function(){
        $(".righttow").append(`
        <div class="seed_show">
            <div class="seed_show_m">
                <div class="seed_show_esc">
                    <span>添加轮播图</span>
                    <span>×</span>
                </div>
                <div class="seed_show_div">
                    <span>描述</span>
                    <input type="text" id="seed-post-txt" placeholder="输入图片的描述">
                    <span>图片上传</span>
                    <div class="seed-file">
                        <img src="/images/app/sc.png"/>
                        <input type="file" id="seed-post-file"/>
                    </div>
                    <button onclick="addseed()">添加</button>
                </div>
            </div>
        </div>
        `);
	        $(".seed_show").fadeIn(500,function(){
	            var showm = document.querySelector(".seed_show_m");
                var esc = document.querySelector(".seed_show_esc");
	            move(showm,esc);
	            //隐藏添加轮播图界面
    		    $(".seed_show_esc span+span").click(function(){
    		        $(".seed_show").fadeOut(500,function(){
    		            $(this).remove();
    		        });
    		    });
	        });
    })
    	//图片在线预览
    $(document).bind("change","#seed-post-file",function(){
        var obj = document.querySelector("#seed-post-file");
	    var url = getObjectURL(obj.files[0]);
	    if(url){
			$(".seed-file img").attr("src",url).css({"width":"100%","height":"100%"});
	    }
		var imgtxt = $("#seed-post-file").val();
		var index = imgtxt.lastIndexOf('.'); 
		var str = imgtxt.substr(index,4); 
		strtype = str.toLowerCase(); 
		if(strtype!=".png" && strtype!=".jpg" && strtype!=".gif"){ 
			$("#seed-post-file").val(""); 
			win("请上传gif, jpg, png格式的图片！");
		}
	});
    
	    //获取轮播图信息
   $(".seed_w .seed_n").click(function(){
        //获取改变图片的索引
        var id = $(".seed_w .seed_n").index(this) + 1;
        $.ajax({
            url:"/index/user/seed",
            type:"GET",
            data:{
                id : id
            },
            dataType:'json',
            success:function(data){
                seed(data);
            },
            error:function(xhr,status,error){
                console.log(xhr+"|"+status+"|"+error);
            }
    		 });
            		 //获取数据成功调用
    function seed(data){
        $(".righttow").append(`
            <div class="seed_show">
                <div class="seed_show_m">
                    <div class="seed_show_esc">
                        <span>修改</span>
                        <span>×</span>
                    </div>
                    <div class="seed_show_div">
                        <span>描述</span>
                        <input type="text" id="seed-post-txt" value="${data.title}" placeholder="输入图片的描述">
                        <span>图片上传</span>
                        <div class="seed-file">
                            <img src="${data.src}"/>
                            <input type="file" id="seed-post-file"/>
                        </div>
                        <button class="seed-button" data-id="${data.id}">修改</button>
                    </div>
                </div>
            </div>
            `);
	       $(".seed_show").fadeIn(300);
	       let a = document.querySelector(".seed_show_m");
	       let b = document.querySelector(".seed_show_esc");
	       //定义可拖动
	       move(a,b);
	       //关闭窗口
	        $(".seed_show_esc span+span").click(function(){
	            $(".seed_show").fadeOut(300,function(){
	                $(this).remove();
	            });
	        })
	        
	        //修改提交
	        $(".seed_show .seed-button").click(function(){
	            let id = $(this).attr("data-id");
	            var formdata = new FormData();
	            if($("#seed-post-file")[0].files[0]){
	                formdata.append("img" , $("#seed-post-file")[0].files[0]);
	            }
                formdata.append("id" , id);
                formdata.append("title" , $("#seed-post-txt").val());
		         $.ajax({
                    url:"/index/user/src",
                    type:"POST",
                    data:formdata,
                    cache : false,
                    processData : false,
                    contentType : false,
                    success:function(data){
                        if($("#seed-post-file")[0].files[0]){
                            toast("修改成功！");
    		                $(".seed-file img").attr("src",data);
                            $(".seed_w img").eq(id - 1).attr("src",data);
    		            }else{
                            toast(data);
    		            }
                    },
                    error:function(xhr,status,error){
                        console.log(xhr+"|"+status+"|"+error);
                    }
            		 });
	            })
	        }
                    
    		     })

    
    $("#offn").click(function(){
        $(".balt").fadeOut();
    })
    //事件裁入结束
		})
		
		
		function alt(id){
		    $.ajax({
		        url:"/foot",
		        type:"POST",
		        data:{
		            id:id
		        },
		        success:function(data){
                    $(".alt .alt_content").text(data.content);
                    $(".alt .alt_name").text("来自《"+data.name+"》的反馈");
                    $(".alt .alt_xx").text("信息：" + data.xx);
                    $(".balt").fadeIn();
                    $(".alt").slideDown();
                },
                error:function(xhr,status,error){
                    console.log(xhr+"|"+status+"|"+error);
                }
		    });
		}
		
		//添加轮播图处理
	    function addseed(){
	        if($(".seed_n").length>=8){
	            win("无法继续添加轮播图啦！<br>轮播图已存在8张了");
	            return;
	        }
	        var ctxt = $("#seed-post-txt").val();
	        var img = $("#seed-post-file")[0].files[0];
	        if(ctxt.length>=2&&img){
	            var data = new FormData();
                data.append("img" , $("#seed-post-file")[0].files[0]);
                data.append("title" , ctxt);
		         $.ajax({
                    url:"/index/user/add",
                    type:"POST",
                    data:data,
                    cache : false,
                    processData : false,
                    contentType : false,
                    dataType:'json',
                    success:function(data){
                       $(".seed_w").append(`
                       <div class="seed_n">
    	                    <img title="${data.title}" src="${data.src}"/>
    	                </div>
                       `);
                        $("#seed-post-txt").val("");
	                    $("#seed-post-file").val("");
	                    $(".seed-file img").attr("src","/images/app/sc.png").attr("style","");
                        win("添加成功");
                    },
                    error:function(xhr,status,error){
                        console.log(xhr+"|"+status+"|"+error);
                        win("添加失败");
                    }
            		 });
    	        }else{
    	            win("请检查数据是否完整！");
    	        }
		    }
		
		function upimg(obj,id){
            if( obj.value == "" ) {
                return;
            }
            var formdata = new FormData();
            //<input type="file" name="img" value="" />
            formdata.append("img" , $(obj)[0].files[0]);//获取文件法二
            formdata.append("id" , id);
            console.log(formdata)
            $.ajax({
                type : 'post',
                url : '/index/user/src', //接口
                data : formdata,
                cache : false,
                processData : false, // 不处理发送的数据，因为data值是Formdata对象，不需要对数据做处理
                contentType : false, // 不设置Content-type请求头
                success : function(response){
                    console.log(response);
                },
                error : function(){
                    
                }
            });
        }
            function getObjectURL(file) {
                var b = file.size;
                if(b<1024){
                    var title = (b).toFixed(0) + "字节";
                }else if(b>1024&&b<(1024*1024)){
                    var title = (b/1024).toFixed(2) + "KB";
                }else if(b>(1024*1024)){
                    var title = (b/1024/1024).toFixed(2) + "MB";
                }
                //显示图标基本信息
                $("#seed-post-file").attr("title",file.name + "\n大小："+ title);
			    var url = null ;
			    // 下面函数执行的效果是一样的，只是需要针对不同的浏览器执行不同的 js 函数而已
			    if (window.createObjectURL!=undefined) { // basic
			        url = window.createObjectURL(file) ;
			    } else if (window.URL!=undefined) { // mozilla(firefox)
			        url = window.URL.createObjectURL(file) ;
			    } else if (window.webkitURL!=undefined) { // webkit or chrome
			        url = window.webkitURL.createObjectURL(file) ;
			    }
			    return url ;
			}
			function move(dv,mdv){
			    //鼠标没按下时默认关闭
            	var isD = false;
            	//存储鼠标X轴
            	var x = 0;
            	//存储鼠标Y轴
            	var y = 0;
            	//存储离左边的距离
            	var l = 0;
            	//存储离顶部的距离
            	var t = 0;
            	//鼠标移动事件
            	window.onmousemove = function(event){
            	    let even = event || window.event;
            		if(!isD){
            		    //如果为假就不可移动
            			return;
            		}
            		//需要往顶部移动的距离
                	var nn = even.clientY - (y-t);
                	//需要往左边移动的距离
					var n = even.clientX - (x-l);
					//窗口长度 - 自身长度
					var ww = $(window).width()-$(dv).width();
					//窗口高度 - 自身高度
            		var wh = $(window).height()-$(dv).height();
            		//上一级的宽度
            		var rg = $(dv).parents().width() - $(dv).width();
            		    //判断是否触碰到上下左右的边缘
                		if(n>=ww){
                			n = n>=ww?ww:n;
                		}else{
                			n = n<=0?0:n;
                		}
                		//如果到边缘无法拉动
                		n = n>=rg?rg:n;
                		if(nn>=wh){
                			nn = nn>=wh?wh:nn;
                		}else{
                			nn = nn<=0?0:nn;
                		}
                	//同步设置左边距离
            		dv.style.left = n +"px";
            		//同步设置顶部距离
            		dv.style.top = nn +"px";
            	}
        	    $(mdv).mousedown(function(event){
            		var event = event || window.event;
            		//鼠标的X轴
            		x = event.clientX;
            		//鼠标的Y轴
            		y = event.clientY;
            		//离左边的距离
            		l = dv.offsetLeft;
            		//离顶部的距离
            		t = dv.offsetTop;
            		//鼠标按下开启
            		isD = true;
            	})
            	$(mdv).mouseup(function(){
            	    //鼠标抬起后关闭
            		isD = false;
            		})
			}
			//删除元素
			function dele(id){
			    $(id).remove();
			}
			//文本域变化事件
		    function textarea(){
		        $(".saltw textarea").change(function(){
		            //console.log($(this).val())
		        })
		    }
		    function ajax(url,type,data){
		        $.ajax({
                    url:url,
                    type:type,
                    data:data,
                    success:function(data){
                        win(data);
                    },
                    error:function(xhr,status,error){
                        console.log(xhr+"|"+status+"|"+error);
                    }
            		 });
		    }
		    //快捷ajax提交
		    function getajx(id){
		         $.ajax({
                    url:url,
                    type:type,
                    data:data,
                    success:function(data){
                        win(data);
                    },
                    error:function(xhr,status,error){
                        console.log(xhr+"|"+status+"|"+error);
                    }
            		 });
		    }
    //获取统计图信息、已废弃
    function chart(){
        $.ajax({
        url:"/index/user/cs",
        type:"GET",
        dataType:'json',
        success:function(yes){
           console.log(yes)
        },
        error:function(xhr,status,error){
            console.log(xhr+"|"+status+"|"+error);
        }
		 });
    }
    //文章上下架
    function SelectChange(id){
        $.ajax({
            url:"/index/user/SelectChange",
            type:"POST",
            data:{
                id:id
            },
            success:function(data){
                toast(data);
            },
            error:function(xhr,status,error){
                console.log(xhr+"|"+status+"|"+error);
            }
		 });
    }
    //关闭打开网站
    function off(){
        $.ajax({
            url:"/index/user/off",
            type:"POST",
            success:function(data){
                win(data);
            },
            error:function(xhr,status,error){
                console.log(xhr+"|"+status+"|"+error);
            }
		 });
    }
    //退出登录
    function edit(){
        //if($.removeCookie('name')||$.removeCookie('star'))
        if($.removeCookie('username')&&$.removeCookie('password')&&$.removeCookie('timestamp')){
            alert("已退出登录");
            history.go(0); 
        }
    }