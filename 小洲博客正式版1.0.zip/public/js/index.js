$(function(){
    //右侧栏底部标签颜色
    $(".recommend_nr a").eq(1).css("color","#ff6348");
    $(".recommend_nr a").eq(2).css("color","#18dcff");
    $(".recommend_nr a").eq(3).css("color","#58B19F");
    $(".recommend_nr a").eq(4).css("color","#706fd3");
    $(".recommend_nr a").eq(5).css("color","#c56cf0");
	var dsq = null;
	$('.nav-menu,.nav-list').click(function(e){
		e.stopPropagation();
		})
	$('nav').find('.nav-menu').click(function(e){
		$('.nav-list').toggleClass('open');
	})
	//微信图片显示隐藏
	$("#wx").mouseover(function(){
		$(".hid").show();
	}).mouseout(function(){
		$(".hid").hide();
	})
	function footer(){
		//设置页脚永远为底部
		var weight = $(window).outerHeight();
		var height = $(document).outerHeight();
		var footerH = $("footer").outerHeight();
		var Top = $("footer").position().top;
		var Theight = weight - footerH - Top;
		var T = "translateY("+ Theight +"px)";
		if(!(height>weight)){
			$("footer").css('transform',T);
		}
	}
	footer();

	$(window).scroll(function(){
		//窗口大小被改变运行页脚为底部函数
		footer();
		topimg();
	})
	$(window).resize(function(){
		footer();
		topimg();
	})
	function open(){
		dsq = setInterval(function(){
			var top = document.documentElement.scrollTop || document.body.scrollTop;
			top -=100;
			window.scrollTo(0,top);
		},5);
	}
	//点击回到顶部
	$("#topimg").click(function(){
		open();
	})
	function topimg(){
	    var top = document.documentElement.scrollTop || document.body.scrollTop;
		if(top>=100){
			$(".top").fadeIn();
		}else{
			$(".top").fadeOut();
		}
		if(top==0){
			clearInterval(dsq);
		}
	}
	//返回顶部
	topimg();
	//设置移动条的默认长度是第一个标签的长度
	$(".hr").width($(".swhr>span").eq(0).innerWidth());
	//给每个span加事件
	$(".swhr>span").click(function(){
		var b = this.offsetLeft;
		$(".hr").animate({left:b,width:this.offsetWidth});
		let long = $(".nei-m").eq(0).width();
		var i = $(this).index();
		$(".nei-m").eq(i).fadeIn().siblings().fadeOut();
	})

	var i=0;
	var sum = $(".ull .li").length;
	var time = null;
	var timer = 3000;//3秒跳转
	for(var a=0;a<sum;a++){
		if(a==0) $(".pu").append("<li class='hov'></li>");
		else $(".pu").append("<li></li>");
	}
		
	function star(){
		if(i==sum){
			i=0;
		}
		//let long = $(".li").width();
		let long = (100*-i) + "%";
		$(".ull>li").eq(i).animate({left:long}).siblings().animate({left:long});
		$(".pu>li").eq(i).addClass("hov").siblings().removeClass("hov");
	}
	function lunbo(){
	    clearInterval(time);
		time = setInterval(function(){
			i++;
			if(i==sum){
				i=0;
			}
			star();
		},timer)
	}
		
	$(".ull .li").eq(0).show();
	lunbo();
	$(".pu>li").click(function(){
		i=$(this).index();
		star();
		lunbo();
	})
	//监听用户是否离开页面
    	document.addEventListener('visibilitychange',function(){
      var isHidden = document.hidden;
       if(isHidden){
            //离开 
            clearInterval(time);
       } else {
            //进入
            lunbo();
       }
      }
    );
    //搜索栏的显示与隐藏
    $(".search").click(function(){
        $("body").append(`
            <div class="search_background">
                <div class="search_div">
                    <div class="search_esc">
                        <p>全站搜索</p>
                        <span>×</span>
                    </div>
                    <form action="/search" method="get">
                        <div>
    				    <input type="text" autocomplete="off" spellcheck="false" name="text" />
    				    <input type="submit" value="搜索">
    				    </div>
    			    </form>
                </div>
            </div>
        `);
        $(".search_background").fadeIn(100);
        $(".search_esc span").click(function(){
            $(".search_background").fadeOut(100,function(){
                $(this).remove();
            })
        })
    })
    function allsz(){
        $.ajax({
        url:"/stas",
        type:"GET",
        data:{name:"all"},
        dataType:"json",
        success:function(data){
            return data;
        },
        error:function(xhr,status,error){
            console.log(xhr+"|"+status+"|"+error);
        }
	 });
    }
})