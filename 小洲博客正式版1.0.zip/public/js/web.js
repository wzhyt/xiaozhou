$(function(){
	
	function width(){
		var w = $(".webmaster img");
		for(var i=0;i<w.length;i++){
			var imgw = $(".webmaster img").eq(i).outerWidth();
			var mw = $(".webmaster").width();
			$(".webmaster img").eq(i).css({'height':'auto'});
			if(imgw>mw){
				$(".webmaster img").eq(i).css({'width':mw});
			}
		}
	}
	width();
	$(window).scroll(function(){
		width();
	})
	$(window).resize(function () {
		width();
	});
	var images = $(".webmaster img");
if(images){
	$.each(images,function(){
		$(this).click(function(){
			var width = $(this).naturalWidth;
			var height = $(this).naturalHeight;
			var src = $(this).attr("src");
			var NewObj = "<div class='boxx'><img src=" + src + " width="+width+" height="+height+"></div>"
			//$("body").css({'overflow':'hidden'})
			 $("body").append(NewObj);
				 $(".boxx").click(function(){
					 $(".boxx").remove();
					 //$("body").css({'overflow':'auto'})
				 })
		})
	})
}
})