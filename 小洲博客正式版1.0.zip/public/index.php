<?php
// [ 应用入口文件 ]


//判断是否安装
if(file_exists("config.json"))
{
    define('APP_PATH', __DIR__ . '/../app/');
}
else
{
    // 定义应用目录
    define('APP_PATH', __DIR__ . '/../install/');
    define('APP_PAHH', __DIR__ . '/../app/');
}

//自定义目录
//define('CONF_PATH', __DIR__ . '/../config/');
// 加载框架引导文件
require __DIR__ . '/../thinkphp/start.php';
